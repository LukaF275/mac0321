package src.mvc;

// Interface para controlador
// para permitir que troquemos de controlador
// no futuro

public interface Controller {

}
